//
//  MieMieMieTests.swift
//  MieMieMieTests
//
//  Created by Julie Zhang on 2025-11-03.
//

import Testing
@testable import MieMieMie

struct MieMieMieTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
