import SwiftUI

struct RecoverySummaryView: View {
    @Environment(\.dismiss) private var dismiss
    
    @State private var showGoodJobPopup = false
    @State private var shareSheetPresented = false
    
    var body: some View {
        ZStack {
            ScrollView {
                VStack(spacing: 24) {
                    headerSection
                    progressHighlightCard
                    metricsGrid
                    insightsSection
                    exercisesSection
                    nextStepsSection
                    Spacer(minLength: 40)
                }
                .padding(.top, 16)
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("Recovery Summary")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Done") {}
                        .disabled(true)
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        shareSheetPresented = true
                    } label: {
                        Label("Share to Community", systemImage: "square.and.arrow.up")
                    }
                }
            }
            .sheet(isPresented: $shareSheetPresented) {
                ShareToCommunitySheet()
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    withAnimation(.spring(response: 0.45, dampingFraction: 0.8)) {
                        showGoodJobPopup = true
                    }
                }
            }
            
            if showGoodJobPopup {
                goodJobPopup
                    .transition(.scale.combined(with: .opacity))
                    .zIndex(1)
            }
        }
    }
    
    private var headerSection: some View {
        VStack(spacing: 12) {
            Text("Today's recovery plan is complete")
                .font(.system(size: 22, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
            
            Text("You’ve maintained a 12-day streak, surpassing 86% of users in consistency. Keep it up — you’re getting closer to your recovery goals!")
                .font(.system(size: 14))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 24)
        }
        .padding(.top, 12)
    }
    
    private var progressHighlightCard: some View {
        VStack(spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Total Duration")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    Text("48 min")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                }
                Spacer()
                VStack(alignment: .leading, spacing: 6) {
                    Text("Recovery Quality Score")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    HStack(spacing: 6) {
                        Text("A-")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                        Text("Improved by 5%")
                            .font(.system(size: 12))
                            .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Completion Status")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                
                ProgressView(value: 0.92)
                    .accentColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                
                HStack {
                    Text("5 / 5 Exercises Completed")
                        .font(.system(size: 13))
                        .foregroundColor(.gray)
                    Spacer()
                    Text("0 Remaining")
                        .font(.system(size: 12))
                        .foregroundColor(Color.gray.opacity(0.7))
                }
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.08), radius: 14, x: 0, y: 7)
        )
        .padding(.horizontal, 20)
    }
    
    private var metricsGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 16), GridItem(.flexible(), spacing: 16)], spacing: 16) {
            metricCard(title: "Pain Level", value: "2/10", subtitle: "Down 1 from yesterday")
            metricCard(title: "Knee Joint Range", value: "132°", subtitle: "Approaching clinical goal")
            metricCard(title: "Muscle Strength Completion", value: "94%", subtitle: "Weekly goal achieved")
            metricCard(title: "Heart Rate Range", value: "68–112 bpm", subtitle: "Moderate training load")
        }
        .padding(.horizontal, 20)
    }
    
    private func metricCard(title: String, value: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.system(size: 13))
                .foregroundColor(.gray)
            Text(value)
                .font(.system(size: 22, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
            Text(subtitle)
                .font(.system(size: 12))
                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
        )
    }
    
    private var insightsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Today's Highlights")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                .padding(.horizontal, 4)
            
            insightRow(title: "Effective IT Band Relaxation", detail: "Pain level has decreased for three consecutive days — maintain current foam rolling frequency and duration.")
            insightRow(title: "Balanced Quadriceps Strength", detail: "Left–right output difference under 5%; consider gradually increasing load.")
            insightRow(title: "Good Sleep Quality", detail: "Deep sleep ratio up 12%, supporting tissue recovery.")
        }
        .padding(.horizontal, 20)
    }
    
    private func insightRow(title: String, detail: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
            Text(detail)
                .font(.system(size: 13))
                .foregroundColor(.gray)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.04), radius: 8, x: 0, y: 4)
        )
    }
    
    private var exercisesSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Exercise Review")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                .padding(.horizontal, 4)
            
            ForEach(sampleExercises) { exercise in
                exerciseRow(exercise)
            }
        }
        .padding(.horizontal, 20)
    }
    
    private func exerciseRow(_ item: ExerciseSummary) -> some View {
        HStack(alignment: .top, spacing: 16) {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(red: 0.91, green: 0.96, blue: 1.0))
                .frame(width: 64, height: 64)
                .overlay(
                    Image(systemName: item.icon)
                        .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                        .font(.system(size: 24))
                )
            
            VStack(alignment: .leading, spacing: 8) {
                Text(item.title)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                Text(item.detail)
                    .font(.system(size: 13))
                    .foregroundColor(.gray)
                HStack(spacing: 12) {
                    Label(item.duration, systemImage: "clock")
                    Label(item.intensity, systemImage: "flame.fill")
                }
                .font(.system(size: 12))
                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
            }
            Spacer()
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.06), radius: 10, x: 0, y: 5)
        )
    }
    
    private var nextStepsSection: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Next Steps")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                .padding(.horizontal, 4)
            
            VStack(alignment: .leading, spacing: 12) {
                suggestionRow(symbol: "calendar.badge.clock", title: "Schedule Friday follow-up visit", caption: "Bring your latest training record and pain log.")
                suggestionRow(symbol: "camera.viewfinder", title: "Record knee mobility video", caption: "For the next online assessment, to track progress.")
                suggestionRow(symbol: "figure.strengthtraining.traditional", title: "Add 10-min core stability training tomorrow", caption: "Improves knee stability and reduces impact.")
            }
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(Color.white)
                    .shadow(color: Color.black.opacity(0.06), radius: 12, x: 0, y: 6)
            )
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 8)
    }
    
    private func suggestionRow(symbol: String, title: String, caption: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 20))
                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                .frame(width: 28)
            
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                Text(caption)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            Spacer()
        }
    }
    
    private var goodJobPopup: some View {
        ZStack {
            Color.black.opacity(0.35)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        showGoodJobPopup = false
                    }
                }
            
            VStack(spacing: 16) {
                Image(systemName: "hand.thumbsup.fill")
                    .font(.system(size: 36))
                    .foregroundColor(Color.white)
                    .padding()
                    .background(
                        Circle()
                            .fill(Color(red: 0.32, green: 0.52, blue: 0.91))
                    )
                
                Text("Good job!")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                
                Text("You’ve completed all your recovery exercises today and maintained your streak. Keep it up — we’re getting stronger together!")
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                Button {
                    withAnimation(.easeInOut(duration: 0.25)) {
                        showGoodJobPopup = false
                    }
                } label: {
                    Text("Continue to Summary")
                        .font(.system(size: 15, weight: .semibold))
                        .padding(.vertical, 12)
                        .padding(.horizontal, 32)
                        .background(Color(red: 0.32, green: 0.52, blue: 0.91))
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
            }
            .padding(28)
            .background(
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .fill(Color.white)
            )
            .padding(.horizontal, 32)
        }
    }
    
    private var sampleExercises: [ExerciseSummary] {
        [
            .init(icon: "waveform.path.ecg", title: "Static Balance Training", detail: "Hold balance for 3 sets, 45 sec each, 30 sec rest.", duration: "15 min", intensity: "Light"),
            .init(icon: "figure.strengthtraining.functional", title: "Step-Up + Lunge", detail: "Alternate legs, focus on knee alignment. Use brace if needed.", duration: "18 min", intensity: "Moderate"),
            .init(icon: "arrow.triangle.2.circlepath", title: "Foam Rolling", detail: "Focus on outer thigh and IT band, 2 min per area.", duration: "10 min", intensity: "Relaxing")
        ]
    }
}

struct ExerciseSummary: Identifiable {
    let id = UUID()
    let icon: String
    let title: String
    let detail: String
    let duration: String
    let intensity: String
}

struct ShareToCommunitySheet: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Share to Community")
                    .font(.system(size: 20, weight: .semibold))
                    .padding(.top, 20)
                
                Text("Add a short message to share your recovery progress with the community.")
                    .font(.system(size: 13))
                    .foregroundColor(.gray)
                
                TextEditor(text: .constant("Completed all my recovery exercises today — pain level decreased noticeably! Sharing my progress with everyone."))
                    .frame(height: 140)
                    .padding(12)
                    .background(Color(UIColor.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                
                Toggle("Sync to my Recovery Calendar", isOn: .constant(true))
                    .toggleStyle(SwitchToggleStyle(tint: Color(red: 0.32, green: 0.52, blue: 0.91)))
                
                Spacer()
                
                Button {
                    dismiss()
                } label: {
                    Text("Share Now")
                        .font(.system(size: 16, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .foregroundColor(.white)
                        .background(Color(red: 0.32, green: 0.52, blue: 0.91))
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
            }
            .padding(20)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
            }
        }
    }
}

#Preview {
    RecoverySummaryView()
}
