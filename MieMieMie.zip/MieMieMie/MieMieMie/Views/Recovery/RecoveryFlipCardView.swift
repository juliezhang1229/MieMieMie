//
//  RecoveryFlipCardView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-06.
//

import SwiftUI

struct RecoveryFlipCardView: View {
    var body: some View {
        NavigationStack {
            ZStack(alignment:.top) {
                Capsule()
                    .fill(Color("buttonColor"))
                    .frame(width: 500, height: 500)
                    .offset(y:-320)
                
                VStack {
                    HStack {
                        VStack(alignment:.leading) {
                            Text("Lap 1")
                            Text("Exercise 1")
                        }
                        .foregroundColor(Color.white)
                        .font(.system(size:25, weight:.bold))
                        Spacer()
                        Text("28S Left")
                            .foregroundColor(Color.white)
                            .font(.system(size:30, weight:.heavy))
                    }
                    .frame(width:330)
                    .offset(y:-20)
                    VStack(alignment:.center) {
                        Text("Stretch")
                            .font(.system(size:27,weight:.bold, design:.rounded))
                            .foregroundColor(Color("buttonColor"))
                            .offset(y:30)
                        Spacer()
                        /*Text("Notice: This test needs two people to conduct")
                         .font(.system(size:22,weight:.bold, design:.rounded))
                         .foregroundColor(Color("buttonColor"))
                         .padding()*/
                        Image("stretch")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 250, height: 300,alignment:.init(horizontal: .center, vertical: .center))
                            .offset(y:30)
                            .clipShape(Rectangle())
                        //.cornerRadius(10)
                        //.clipShape(Circle())
                            .overlay {
                                Rectangle()
                                    .stroke(Color("buttonColor"), lineWidth: 4)
                            }
                        Spacer()
                        Text("Slightly wider than shoulder-width grip")
                            .font(.system(size:18,weight:.bold, design:.rounded))
                            .foregroundColor(Color("buttonColor"))
                            .offset(y:-30)
                    }
                    .frame(width: 330, height:500)
                    .background(Color(.white))
                    .cornerRadius(10)
                    .shadow(color:.black.opacity(0.3), radius: 8, x:0, y:5)
                    
                    HStack {
                        Button(action: {
                            //some action
                        }) {
                            Image(systemName: "backward.end.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                        Spacer()
                        Button(action: {
                            //some action
                        }) {
                            Image(systemName: "pause.circle.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                        Spacer()
                        NavigationLink {
                            RecoverySummaryView()
                        } label: {
                            Image(systemName: "forward.end.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                    }
                    .frame(width:280)
                    .offset(y:25)
                    .padding()
                }
            }
        }
    }
}

#Preview {
    RecoveryFlipCardView()
}
