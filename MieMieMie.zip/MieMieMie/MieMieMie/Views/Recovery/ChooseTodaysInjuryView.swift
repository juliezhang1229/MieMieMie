//
//  ChooseTodaysInjuryView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-11.
//

import SwiftUI

struct ChooseTodaysInjuryView: View {
    var body: some View {
        VStack {
            HStack {
                Text("Today's injury")
                    .font(.title)
                    .bold()
                    .foregroundColor(Color("buttonColor"))
                    .padding()
                Spacer()
            }
            HStack {
                InjuryDropdownView()
                    .offset(x:-15)
                Text("45\nmin")
                    .frame(alignment:.center)
                    .foregroundColor(Color("buttonColor"))
                    .bold()
                    .frame(width:80, height: 60)
                    .background(Color("SquatBg"))
                    .cornerRadius(15)
            }
            .offset(y:-20)
            //.padding()
            RehabExercisesView()
                .padding(.horizontal)
        }
        .frame(width: 370, height:500)
        .background(Color(.white))
        .cornerRadius(20)
        .shadow(color:.black.opacity(0.3), radius: 8, x:0, y:5)
    }
}

struct InjuryDropdownView: View {
    var options = ["Triceps strain", "Sprained ankle", "Tendonitis"]
    @State private var selectedOption: String = "Triceps strain"
    
    var body: some View {
        VStack {
            Menu {
                ForEach(options, id: \.self) { option in
                    Button(action: {
                        selectedOption = option
                    }) {
                        Text(option)
                    }
                }
            } label: {
                HStack {
                    Text(selectedOption)
                    Image(systemName: "chevron.down")
                }
                .foregroundColor(Color("buttonColor"))
                .font(.title)
                .bold()
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        /*.overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                        )*/
                )
            }
        }
    }
}

#Preview {
    ChooseTodaysInjuryView()
}
