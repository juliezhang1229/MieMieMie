import SwiftUI

struct CalendarDay: Identifiable {
    let id = UUID()
    let number: Int
    let isCurrentMonth: Bool
}

struct CalendarView: View {
    @Binding var selectedDate: Date
    let calendar = Calendar.current
    
    var body: some View {
        VStack(spacing: 0) {
            // Calendar Header
            HStack {
                Text("2025")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 0/255, green: 82/255, blue: 217/255))
                
                Image(systemName: "chevron.left")
                    .font(.system(size: 12))
                    .foregroundColor(Color(red: 0/255, green: 82/255, blue: 217/255))
                
                Spacer()
                
                Text("Dec")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 0/255, green: 82/255, blue: 217/255))
                
                Spacer()
                
                Button(action: {}) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 12))
                        .foregroundColor(.black)
                        .frame(width: 32, height: 32)
                        .background(Color.white)
                        .cornerRadius(3)
                }
                
                Button(action: {}) {
                    Image(systemName: "calendar")
                        .font(.system(size: 12))
                        .foregroundColor(.black)
                        .frame(width: 32, height: 32)
                        .background(Color.white)
                        .cornerRadius(3)
                }
                
                Button(action: {}) {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 12))
                        .foregroundColor(.black)
                        .frame(width: 32, height: 32)
                        .background(Color.white)
                        .cornerRadius(3)
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 16)
            
            Divider()
                .background(Color(red: 231/255, green: 231/255, blue: 231/255))
            
            // Weekday Headers
            HStack(spacing: 0) {
                ForEach(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], id: \.self) { day in
                    Text(day)
                        .font(.system(size: 14))
                        .foregroundColor(.black.opacity(0.6))
                        .frame(maxWidth: .infinity)
                }
            }
            .padding(.vertical, 10)
            
            // Calendar Grid
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 0), count: 7), spacing: 0) {
                ForEach(calendarDays()) { day in
                    CalendarDayCell(day: day)
                }
            }
            .padding(.bottom, 24)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(color: Color.black.opacity(0.08), radius: 10, x: 0, y: 8)
    }
    
    func calendarDays() -> [CalendarDay] {
        // Two days from previous month
        let previous = [
            CalendarDay(number: 29, isCurrentMonth: false),
            CalendarDay(number: 30, isCurrentMonth: false)
        ]
        // All days in current month (1...31)
        let current = (1...31).map { day in
            CalendarDay(number: day, isCurrentMonth: true)
        }
        // Two days from next month
        let next = [
            CalendarDay(number: 1, isCurrentMonth: false),
            CalendarDay(number: 2, isCurrentMonth: false)
        ]
        return previous + current + next
    }
}

struct CalendarDayCell: View {
    let day: CalendarDay
    
    var body: some View {
        let isHighlighted = [1, 2, 8, 15, 16, 21].contains(day.number) && day.isCurrentMonth
        let isSelected = day.number == 5 && day.isCurrentMonth
        let isCurrentMonth = day.isCurrentMonth
        
        Text("\(day.number)")
            .font(.system(size: 14, weight: isSelected ? .medium : .regular))
            .foregroundColor(
                isSelected ? .black :
                isHighlighted ? .white :
                isCurrentMonth ? .black.opacity(0.9) : .black.opacity(0.26)
            )
            .frame(width: 40, height: 40)
            .background(
                isHighlighted ? Color(red: 67/255, green: 132/255, blue: 230/255) : Color.white
            )
            .cornerRadius(20)
            .padding(.vertical, 2)
    }
}

#Preview {
    CalendarView(selectedDate: .constant(Date()))
}
