//
//  TestMainView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-06.
//

import SwiftUI

struct FlipCardView: View {
    var body: some View {
        ZStack(alignment:.top) {
            Capsule()
                .fill(Color("buttonColor"))
                .frame(width: 500, height: 500)
                .offset(y:-320)
            
            VStack {
                VStack(alignment:.leading) {
                    Text("Hawkins-Kennedy Test")
                        .font(.system(size:27,weight:.bold, design:.rounded))
                        .foregroundColor(Color("buttonColor"))
                        .padding(.horizontal)
                    Text("Notice: This test needs two people to conduct")
                        .font(.system(size:22,weight:.bold, design:.rounded))
                        .foregroundColor(Color("buttonColor"))
                        .padding()
                    Image("hawkins")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 300, height: 200)
                        .offset(y:30)                        .cornerRadius(10)
                        .padding(.horizontal)
                    Text("Then fixate the scapula with one hand and hold onto the elbow with other hand")
                        .font(.system(size:18,weight:.bold, design:.rounded))
                        .foregroundColor(Color("buttonColor"))
                        .padding()
                }
                .frame(width: 330, height:500)
                .background(Color(.white))
                .cornerRadius(10)
                .shadow(color:.black.opacity(0.3), radius: 8, x:0, y:5)
                
                HStack {
                    Button(action: {
                        //some action
                    }) {
                        Image(systemName: "backward.end.fill")
                            .font(.system(size:50))
                            .foregroundColor(Color("buttonColor"))
                    }
                    Spacer()
                    Button(action: {
                        //some action
                    }) {
                        Image(systemName: "pause.circle.fill")
                            .font(.system(size:50))
                            .foregroundColor(Color("buttonColor"))
                    }
                    Spacer()
                    Button(action: {
                        //some action
                    }) {
                        Image(systemName: "forward.end.fill")
                            .font(.system(size:50))
                            .foregroundColor(Color("buttonColor"))
                    }
                }
                .frame(width:280)
                .offset(y:30)
                .padding()
            }
        }
    }
}
#Preview {
    FlipCardView()
}
