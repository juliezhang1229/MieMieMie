//
//  AssessmentResultChatView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-11.
//

import SwiftUI

struct AssessmentResultChatView: View {
    let Messages = [
        MessageModel(user: "bot", profileImage: "chatgpt", message: "I’ve analyzed your movement — here’s your Hawkins–Kennedy assessment result 👇\n\n⸻\n\n🩻 Test Summary (Right Shoulder)\n\nResult: Mildly Positive\nForm Accuracy: 93% (motion matched standard Hawkins–Kennedy sequence)\nDetected Limitation: Internal rotation range slightly restricted, especially around 70°–80° angle.\n\n⸻\n\n💡 Recommendations\n\n•    🧊 Short term: Apply ice for 10–15 min post-activity if tenderness persists.\n\n•    💪 Next step: Begin light scapular retraction and isometric external rotation exercises to relieve anterior shoulder strain.\n•    🔄 Avoid: Overhead pressing, lateral raises above 90°, or fast internal rotations for now.\n•    📆 Recheck: Re-do the Hawkins–Kennedy test in 5 days to monitor pain response."),
        MessageModel(user: "janja", profileImage: "janja", message: "So… is it serious? Should I stop training completely?"),
        MessageModel(user: "bot", profileImage: "chatgpt", message: "Not serious — this looks like an early-stage impingement rather than a tear.\nPause heavy pressing or overhead work for a few days, but you can keep training your legs, core, and light pulling movements.\nIf pain rises above 7/10, or you feel sharp catching during rotation, I’d recommend seeing a physiotherapist for an in-person evaluation."),
        MessageModel(user: "janja", profileImage: "janja", message: "Got it. Can you show me what exercises I can do now?"),
        MessageModel(user: "bot", profileImage: "chatgpt", message: "Absolutely. I’ll load a set of “Shoulder Recovery – Phase 1” drills for you:\n\n1.    Scapular Retraction Holds – 3×12\n\n2.    Wall Angels (pain-free range) – 2×10\n\n3.    Isometric External Rotation with Towel – 3×15 sec hold\n\n4.    Pendulum Swings – 3×30 sec")
    ]
    var body: some View {
        NavigationStack {
            VStack(spacing:0) {
                UpperUpperTabView(title: "Assess")
                ScrollView {
                    VStack {
                        BotMessageView(message: Messages[0])
                        UserMessageView(message:Messages[1])
                        BotMessageView(message: Messages[2])
                        UserMessageView(message: Messages[3])
                        BotMessageView(message: Messages[4])
                        AddRecoveryPlanBubbleView()
                    }
                }
                .padding()
                TypeMessageView()
                    .overlay{
                        LinearGradient(
                            stops: [
                                Gradient.Stop(color: .clear, location: 0),
                                Gradient.Stop(color: Color("gradient"), location:0.8)
                            ],
                            startPoint:.top,
                            endPoint:.bottom
                        )
                    }
                }
            }
        }
}

struct AddRecoveryPlanBubbleView: View {
    var body: some View {
        HStack(alignment:.bottom, spacing:15) {
            Image("chatgpt")
                .resizable()
                .frame(width:40, height:40, alignment:.center)
            VStack {
                Text("Do you want me to add these exercises to your recovery plan?")
                    .bold()
                    .offset(x:-5, y:5)
                Spacer()
                NavigationLink{
                    RecoveryView(selectedTab:.constant(4))
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius:8)
                            .frame(width:220, height:50)
                            .offset(x:20, y:-5)
                            .foregroundColor(Color("buttonColor"))
                        Text("Add to recovery plan")
                            .font(.title2)
                            .bold()
                            .foregroundColor(.white)
                            .offset(x:20, y:-5)
                    }
                }
            }
            .frame(width:260, height:130)
            .padding(10)
            .foregroundColor(Color.black)
            .background(Color(UIColor(red:240/255, green:240/255, blue: 240/255, alpha:10)))
            .cornerRadius(10)
            .clipShape(RoundedRectangle(cornerRadius:10))
            .overlay {
                RoundedRectangle(cornerRadius:10)
                    .stroke(Color("buttonColor"), lineWidth: 4)
            }
            //.shadow(radius:10)
            Spacer()
        }
    }
}

#Preview {
    AssessmentResultChatView()
}
