//
//  KiroWeenView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-07.
//

import SwiftUI

struct BodyScanCameraView: View {
    @State private var showAnalyzingView = false
    @State private var navigateToAssessInjury = false
    
    var body: some View {
        ZStack {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                VStack {
                    Text("Please stand in front of  the camera")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.bottom, 24)
                    BodyOutlineView()
                        .frame(width: 180, height: 420)
                        .offset(y:20)
                    Spacer()
                    HStack(spacing: 40) {
                        Button(action: {
                            // Open gallery
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius:8)
                                    .stroke(Color("buttonColor"), lineWidth: 4)
                                    .frame(width:50, height:50)
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.white)
                                    .frame(width: 50, height: 50)
                            }
                        }
                        Spacer()
                        // Capture button
                        Button(action: {
                            showAnalyzingView = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                showAnalyzingView = false
                                navigateToAssessInjury = true
                            }
                        }) {
                            ZStack {
                                Circle()
                                    .stroke(Color.white, lineWidth: 4)
                                    .frame(width: 50, height: 50)
                                
                                Circle()
                                    .fill(Color(red: 0.26, green: 0.55, blue: 0.84))
                                    .frame(width: 50, height: 50)
                            }
                        }
                        Spacer()
                        // Flip camera button
                        Button(action: {
                            // Flip camera
                        }) {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.15, green: 0.15, blue: 0.15))
                                    .frame(width: 60, height: 60)
                                
                                Image(systemName: "arrow.triangle.2.circlepath")
                                    .foregroundColor(.white)
                                    .font(.system(size: 24))
                            }
                        }
                    }
                    .padding(.bottom, 50)
                }
                .frame(width:330, height:700)
                .padding()
            }
            if showAnalyzingView {
                AnalyzingView()
            }
        }
        .navigationDestination(isPresented: $navigateToAssessInjury) {
            AssessmentResultChatView()
        }
    }
}

struct BodyOutlineView: View {
    var body: some View {
        ZStack {
            // Body outline path
            BodyOutlinePath()
                .stroke(Color.white, lineWidth: 4)
        }
    }
}

struct BodyOutlinePath: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        let width = rect.width
        let height = rect.height
        
        // Head (circle)
        let headRadius: CGFloat = 35
        let headCenter = CGPoint(x: width / 2, y: headRadius + 10)
        path.addArc(center: headCenter,
                   radius: headRadius,
                   startAngle: .degrees(0),
                   endAngle: .degrees(360),
                   clockwise: false)
        
        // Neck to shoulders
        let neckBottom = headCenter.y + headRadius
        let shoulderY = neckBottom + 20
        let shoulderWidth: CGFloat = 70
        
        // Right shoulder
        path.move(to: CGPoint(x: width / 2 + 15, y: neckBottom))
        path.addLine(to: CGPoint(x: width / 2 + shoulderWidth, y: shoulderY))
        
        // Left shoulder
        path.move(to: CGPoint(x: width / 2 - 15, y: neckBottom))
        path.addLine(to: CGPoint(x: width / 2 - shoulderWidth, y: shoulderY))
        
        // Torso
        let torsoBottomY = shoulderY + 120
        let waistWidth: CGFloat = 50
        
        // Left torso
        path.addLine(to: CGPoint(x: width / 2 - waistWidth, y: torsoBottomY))
        
        // Right torso
        path.move(to: CGPoint(x: width / 2 + shoulderWidth, y: shoulderY))
        path.addLine(to: CGPoint(x: width / 2 + waistWidth, y: torsoBottomY))
        
        // Left arm
        let armBottomY = torsoBottomY + 55
        path.move(to: CGPoint(x: width / 2 - shoulderWidth, y: shoulderY))
        path.addLine(to: CGPoint(x: width / 2 - shoulderWidth - 10, y: armBottomY))
        
        // Right arm
        path.move(to: CGPoint(x: width / 2 + shoulderWidth, y: shoulderY))
        path.addLine(to: CGPoint(x: width / 2 + shoulderWidth + 10, y: armBottomY))
        
        // Left leg
        let legBottomY = height - 10
        path.move(to: CGPoint(x: width / 2 - waistWidth, y: torsoBottomY))
        path.addLine(to: CGPoint(x: width / 2 - 35, y: legBottomY))
        
        // Right leg
        path.move(to: CGPoint(x: width / 2 + waistWidth, y: torsoBottomY))
        path.addLine(to: CGPoint(x: width / 2 + 35, y: legBottomY))
        
        return path
    }
}

struct AnalyzingView: View {
    @State private var isRotating = false
    
    var body: some View {
        ZStack {
            // Background
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(red: 149/255, green: 144/255, blue: 144/255))
                .opacity(0.88)
                .frame(width: 171, height: 130)
            
            VStack(spacing: 10) {
                // "Analyzing" text
                Text("Analyzing")
                    .font(.system(size: 20, weight: .heavy))
                    .foregroundColor(.white)
                
                // Loading spinner
                LoadingSpinner(isRotating: $isRotating)
                    .frame(width: 39, height: 39)
            }
        }
        .onAppear {
            withAnimation(Animation.linear(duration: 1.0).repeatForever(autoreverses: false)) {
                isRotating = true
            }
        }
    }
}

struct LoadingSpinner: View {
    @Binding var isRotating: Bool
    
    var body: some View {
        Circle()
            .trim(from: 0, to: 0.7)
            .stroke(
                Color.white,
                style: StrokeStyle(
                    lineWidth: 4,
                    lineCap: .round
                )
            )
            .rotationEffect(.degrees(isRotating ? 360 : 0))
    }
}


#Preview {
    NavigationStack {
        BodyScanCameraView()
    }
}
