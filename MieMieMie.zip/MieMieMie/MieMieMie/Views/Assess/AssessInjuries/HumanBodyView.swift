//
//  HumanBodyView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-12.
//
import SwiftUI

struct HumanBodyView: View {
    enum BodyArea: String, CaseIterable {
        case upperArm = "大臂"
    }
    
    enum PainLevel: Int, CaseIterable, Identifiable {
        case none = 0, mild, moderate, severe, unbearable
        
        var id: Int { rawValue }
        
        var title: String {
            switch self {
            case .none: return "无疼痛"
            case .mild: return "轻度"
            case .moderate: return "中度"
            case .severe: return "重度"
            case .unbearable: return "极重"
            }
        }
        
        var barColor: Color {
            switch self {
            case .none: return Color.green.opacity(0.6)
            case .mild: return Color.green
            case .moderate: return Color.orange
            case .severe: return Color.red
            case .unbearable: return Color(red: 0.7, green: 0, blue: 0)
            }
        }
    }
    
    @State private var selectedArea: BodyArea = .upperArm
    @State private var selectedLevel: PainLevel? = nil
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 8) {
                // 顶部标题区域
                VStack(alignment: .leading, spacing: 8) {
                    Text("选择疼痛部位")
                        .font(.title2.weight(.semibold))
                    Text("请选择当前感到疼痛的身体部位，然后评估疼痛等级")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                
                // 疼痛区域（Demo 仅显示大臂）
                HStack(spacing: 16) {
                    ForEach(BodyArea.allCases, id: \.self) { area in
                        Button {
                            selectedArea = area
                            selectedLevel = nil
                        } label: {
                            VStack(spacing: 12) {
                                Image(systemName: "figure.arms.open") // Demo 用 SF Symbol，可换成真实图标
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 48, height: 48)
                                    .padding()
                                    .background(
                                        Circle()
                                            .fill(selectedArea == area ? Color.blue.opacity(0.15) : Color.gray.opacity(0.1))
                                    )
                                
                                Text(area.rawValue)
                                    .font(.headline)
                                    .foregroundColor(selectedArea == area ? Color.blue : Color.primary)
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(selectedArea == area ? Color.blue : Color.gray.opacity(0.3), lineWidth: selectedArea == area ? 2 : 1)
                            )
                        }
                        .buttonStyle(.plain)
                    }
                }
                
                // 疼痛等级选择
                VStack(alignment: .leading, spacing: 5) {
                    Text("疼痛等级")
                        .font(.headline)
                    
                    VStack(spacing: 12) {
                        ForEach(PainLevel.allCases) { level in
                            Button {
                                selectedLevel = level
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(level.title)
                                            .font(.body.weight(.medium))
                                        Text("等级 \(level.rawValue)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    if selectedLevel == level {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.blue)
                                    } else {
                                        Image(systemName: "circle")
                                            .foregroundColor(.secondary)
                                    }
                                }
                                .padding()
                                .background(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .fill(selectedLevel == level ? level.barColor.opacity(0.15) : Color.gray.opacity(0.05))
                                )
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(selectedLevel == level ? level.barColor : Color.gray.opacity(0.1), lineWidth: selectedLevel == level ? 2 : 1)
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                
                Spacer()
                
                // Next 按钮
                NavigationLink {
                    AssessInjuryView()
                } label: {
                    Text("Next")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(selectedLevel != nil ? Color.blue : Color.gray.opacity(0.3))
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .offset(y:-30)
                .disabled(selectedLevel == nil)
            }
            .padding(24)
            .background(Color(UIColor.systemGroupedBackground))
        }
    }
}

struct PainAssessmentDemoView_Previews: PreviewProvider {
    static var previews: some View {
        HumanBodyView()
            .previewDisplayName("疼痛评估 Demo")
    }
}



/*#Preview {
    HumanBodyView()
}*/
