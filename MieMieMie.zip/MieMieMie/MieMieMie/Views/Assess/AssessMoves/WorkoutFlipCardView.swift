//
//  WorkoutFlipCardView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-06.
//

import SwiftUI

struct WorkoutFlipCardView: View {
    var body: some View {
        NavigationStack {
            ZStack(alignment:.top) {
                Capsule()
                    .fill(Color("buttonColor"))
                    .frame(width: 500, height: 500)
                    .offset(y:-320)
                
                VStack {
                    VStack(alignment:.leading) {
                        Text("Barbell Bench Test")
                            .font(.system(size:27,weight:.bold, design:.rounded))
                            .foregroundColor(Color("buttonColor"))
                            .offset(x:30, y:30)
                        Spacer()
                        /*Text("Notice: This test needs two people to conduct")
                         .font(.system(size:22,weight:.bold, design:.rounded))
                         .foregroundColor(Color("buttonColor"))
                         .padding()*/
                        Image("barbell")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 300, height: 300,alignment:.init(horizontal: .center, vertical: .center))
                            .offset(y:30)
                            .cornerRadius(10)
                            .padding(.horizontal)
                        Spacer()
                        Text("Slightly wider than shoulder-width grip")
                            .font(.system(size:18,weight:.bold, design:.rounded))
                            .foregroundColor(Color("buttonColor"))
                            .offset(x:30, y:-30)
                    }
                    .frame(width: 330, height:500)
                    .background(Color(.white))
                    .cornerRadius(10)
                    .shadow(color:.black.opacity(0.3), radius: 8, x:0, y:5)
                    
                    HStack {
                        Button(action: {
                            //some action
                        }) {
                            Image(systemName: "backward.end.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                        Spacer()
                        Button(action: {
                            //some action
                        }) {
                            Image(systemName: "pause.circle.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                        Spacer()
                        NavigationLink {
                            CameraForMovesView()
                        } label: {
                            Image(systemName: "forward.end.fill")
                                .font(.system(size:50))
                                .foregroundColor(Color("buttonColor"))
                        }
                        
                    }
                    .frame(width:280)
                    .offset(y:30)
                    .padding()
                }
            }
        }
    }
}

#Preview {
    WorkoutFlipCardView()
}
