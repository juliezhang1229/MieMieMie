//
//  KiroWeenView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-07.
//

import SwiftUI

struct CameraForMovesView: View {
    @State private var showAnalyzingView = false
    @State private var navigateToAssessInjury = false
    
    var body: some View {
        ZStack {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                VStack {
                    Text("Please stand in front of  the camera")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.bottom, 24)
                    BodyOutlineView()
                        .frame(width: 180, height: 420)
                        .offset(y:20)
                    Spacer()
                    HStack(spacing: 40) {
                        Button(action: {
                            // Open gallery
                        }) {
                            ZStack {
                                RoundedRectangle(cornerRadius:8)
                                    .stroke(Color("buttonColor"), lineWidth: 4)
                                    .frame(width:50, height:50)
                                RoundedRectangle(cornerRadius: 8)
                                    .fill(Color.white)
                                    .frame(width: 50, height: 50)
                            }
                        }
                        Spacer()
                        // Capture button
                        Button(action: {
                            showAnalyzingView = true
                            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                showAnalyzingView = false
                                navigateToAssessInjury = true
                            }
                        }) {
                            ZStack {
                                Circle()
                                    .stroke(Color.white, lineWidth: 4)
                                    .frame(width: 50, height: 50)
                                
                                Circle()
                                    .fill(Color(red: 0.26, green: 0.55, blue: 0.84))
                                    .frame(width: 50, height: 50)
                            }
                        }
                        Spacer()
                        // Flip camera button
                        Button(action: {
                            // Flip camera
                        }) {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.15, green: 0.15, blue: 0.15))
                                    .frame(width: 60, height: 60)
                                
                                Image(systemName: "arrow.triangle.2.circlepath")
                                    .foregroundColor(.white)
                                    .font(.system(size: 24))
                            }
                        }
                    }
                    .padding(.bottom, 50)
                }
                .frame(width:330, height:700)
                .padding()
            }
            if showAnalyzingView {
                AnalyzingView()
            }
        }
        .navigationDestination(isPresented: $navigateToAssessInjury) {
            MovesAssessmentResultsView()
        }
    }
}


#Preview {
    CameraForMovesView()
}
