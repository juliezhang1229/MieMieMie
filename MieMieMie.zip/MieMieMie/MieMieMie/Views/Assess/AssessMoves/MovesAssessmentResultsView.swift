//
//  MovesAssessmentResultsView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-12.
//

import SwiftUI

struct MovesAssessmentResultsView: View {
    let Messages = [
        MessageModel(user: "bot", profileImage: "chatgpt", message: "Got it! I’ve analyzed your form and rep pattern. Let’s go over your bench press assessment\n👇\n\nForm Summary (Overall Score: 8.2 / 10)\n\n✅ Grip width: Excellent — wrists stacked over elbows through most of the motion.\n\n⚖️ Bar path: Slight diagonal drift toward your face on ascent. Try keeping it in a smoother J-curve — starting above your lower chest and ending just over your shoulders.\n\n🔥 Elbow angle: Around 75°, which is solid for chest engagement and shoulder safety.\n\n⚠️ Lower back: Noticeable arch by your third rep. Engage your core and lightly press your feet into the ground for stability without overextending your spine.\n\n💨 Tempo: Good control on the way down, but a bit too fast on the last push — aim for a consistent 2-second eccentric phase."),
        MessageModel(user: "janja", profileImage: "janja", message: "Can you summarize this?"),
        MessageModel(user: "bot", profileImage: "chatgpt", message: "Here's a summary of your assessment result:\n\n•    Strength: Great\n\n•    Stability: Moderate\n\n•    Technique: Improving fast\n\n•    Recommendation: “Control > Weight” — prioritize form until you can maintain alignment across all 5 reps."),
        MessageModel(user: "janja", profileImage: "janja", message: "Thanks! So should I keep the same weight next time or reduce it?"),
        MessageModel(user: "bot", profileImage: "chatgpt", message: "If your goal is hypertrophy, stay at the same weight and aim to clean up the bar path.\n\nIf your goal is pure strength, reduce it slightly (by 2.5–5 kg) to perfect your form — your power output will climb back up even stronger once your bar path is consistent.")
    ]
    var body: some View {
        NavigationStack {
            VStack(spacing:0) {
                UpperUpperTabView(title: "Assess")
                ScrollView {
                    VStack {
                        BotMessageView(message: Messages[0])
                        UserMessageView(message:Messages[1])
                        BotMessageView(message: Messages[2])
                        UserMessageView(message: Messages[3])
                        BotMessageView(message: Messages[4])
                    }
                }
                .padding()
                TypeMessageView()
                    .overlay{
                        LinearGradient(
                            stops: [
                                Gradient.Stop(color: .clear, location: 0),
                                Gradient.Stop(color: Color("gradient"), location:0.8)
                            ],
                            startPoint:.top,
                            endPoint:.bottom
                        )
                    }
                }
            }
        }
}
struct ContentMessageView_1: View {
    var contentMessage: String
    var isCurrentUser: Bool
    var body: some View {
        Text(contentMessage)
            .padding(10)
            .bold()
            .foregroundColor(isCurrentUser ? Color.white: Color.black)
            .background(isCurrentUser ? Color("buttonColor"): Color(UIColor(red:240/255, green:240/255, blue: 240/255, alpha:10)))
            .cornerRadius(10)
    }
}

struct BotMessageView: View {
    var message: MessageModel
    var body: some View {
        HStack(alignment:.bottom, spacing: 15) {
            Image(message.profileImage)
                .resizable()
                .frame(width: 40, height: 40, alignment: .center)
                .cornerRadius(20)
            ContentMessageView_1(contentMessage: message.message,
                               isCurrentUser: false)
            Spacer()
        }
        .padding(.bottom)
    }
}

struct UserMessageView: View {
    var message: MessageModel
    var body: some View {
        HStack(alignment:.bottom,
               spacing: 15) {
            Spacer()
            ContentMessageView_1(contentMessage: message.message, isCurrentUser: true)
            Image(message.profileImage)
                .resizable()
                .frame(width:40, height: 40, alignment:.center)
                .cornerRadius(20)
        }
        .padding(.bottom)
    }
}


struct TypeMessageView: View {
    @State var text = ""
    var body: some View {
        HStack {
            Button(action: {
                //some action
            }) {
                Image(systemName: "face.smiling")
                    .font(.title)
                    .foregroundColor(.gray)
            }
            Spacer()
            VStack {
                TextField("    Enter Text", text: $text)
                    .frame(height:25)
                    .background(Color(.systemGray6))
                    .cornerRadius(20)
                    .padding(.horizontal, 20)
                    //.padding(.vertical, 12)
                    .onTapGesture {
                        //some action
                    }
            }
            //.padding()
            Spacer()
            Button(action: {
                //sendMessage action
            }) {
                Image(systemName: "mic.circle.fill")
                    .font(.title)
                    .foregroundColor(Color("buttonColor"))
            }
        }
        .padding(.horizontal)
        /*.padding(.horizontal)
        .padding(.vertical, 8)*/
        //add shading
        //.background(Color(.systemBackground))
        }
    }

#Preview {
    MovesAssessmentResultsView()
}
