import SwiftUI
import Foundation

struct ChooseListModel: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var backColor: String
}

struct ChooseExerciseView: View {
    @State private var searchText = ""
    //@Environment(\.presentationMode) var presentationMode
    //@State private var goToAssessment = false
    
    // 👇 these are now parameters
    var title: String
    var sport_list: [ChooseListModel]
    
    var filteredList: [ChooseListModel] {
        if searchText.isEmpty {
            return sport_list
        } else {
            return sport_list.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    /*Button(action: {
                        if title == "Choose sport" {
                            goToAssessment = true
                        } else {
                            presentationMode.wrappedValue.dismiss()
                        }
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.gray)
                            .font(.title2)
                    }*/
                    Text(title)
                        .padding(.horizontal)
                        .foregroundColor(Color("buttonColor"))
                        .font(.system(size:40, weight: .bold))
                    Spacer()
                }
                .frame(alignment:.leading)
                .padding()
                .offset(y: 20)
                
                /*NavigationLink(
                    destination: AssessmentView(selectedTab: .constant(1)),
                    isActive: $goToAssessment
                ) {
                    EmptyView() // Invisible trigger
                }*/
                SearchbarView(text: $searchText)
                    .padding()
                
                ScrollView {
                    VStack {
                        ForEach(filteredList) { item in
                            NavigationLink(destination: destinationView(for: item)) {
                                ListView(choose_list: item)
                            }
                        }
                    }
                    .frame(width: 330)
                }
                
                Spacer()
            }
            .navigationBarHidden(true)
        }
    }
    
    // 👇 helper function
    @ViewBuilder
    private func destinationView(for item: ChooseListModel) -> some View {
        if item.name == "Gym Exercises" {
            ChooseExerciseView(
                title: "Gym Exercises",
                sport_list: [
                    ChooseListModel(name: "Chest", image: "", backColor: "blue_2"),
                    ChooseListModel(name: "Arm", image: "", backColor: "blue_0"),
                    ChooseListModel(name: "Shoulder", image: "", backColor: "blue_3"),
                    ChooseListModel(name: "Leg", image: "", backColor: "blue_4"),
                    ChooseListModel(name: "Back", image: "", backColor: "blue_5"),
                    ChooseListModel(name: "Core", image: "", backColor: "blue_6")
                ]
            )
        }
        else if item.name == "Chest" {
            ChooseExerciseView(
                title: "Chest",
                sport_list: [
                    ChooseListModel(name: "Barbell Bench Press", image: "", backColor: "blue_2"),
                    ChooseListModel(name: "Dumbell Fly", image: "", backColor: "blue_0"),
                    ChooseListModel(name: "Butterfly Machine", image: "", backColor: "blue_3"),
                    ChooseListModel(name: "Cable Crossover", image: "", backColor: "blue_4"),
                    ChooseListModel(name: "Push-ups", image: "", backColor: "blue_5"),
                    ChooseListModel(name: "Dip", image: "", backColor: "blue_6")
                ]
            )
        }
        else if (item.name == "Barbell Bench Press" || item.name == "Dumbell Fly" || item.name == "Butterfly Machine" || item.name == "Cabel Crossover" || item.name == "Push-ups" || item.name == "Dip") {
            WorkoutFlipCardView()
        }
        else {
            // Default placeholder for now
            Text("Coming soon for \(item.name)")
                .font(.title)
                .foregroundColor(.gray)
        }
    }
}

struct ListView: View {
    let choose_list: ChooseListModel
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Image(systemName: choose_list.image)
                    .font(.title3)
                    .frame(width:50, height:50)
                    .foregroundColor(Color.black)
                    .background(Color(choose_list.backColor))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                Text(choose_list.name)
                    .font(.title)
                    .bold()
                    .frame(width:250, alignment:.leading)
                    .foregroundColor(Color("buttonColor"))
                    .offset(x:10)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding(.vertical, 12)
            .padding(.horizontal)
            Divider()
        }
    }
}

struct SearchbarView: View {
    @Binding var text: String
    @State private var isEditing = false
    
    var body: some View {
        HStack {
            TextField("Search ...", text: $text)
                .padding(7)
                .padding(.horizontal, 25)
                .background(Color("SquatBg"))
                .font(.system(size:25))
                .cornerRadius(10)
                .onTapGesture {
                    self.isEditing = true
                }
            if isEditing {
                Button(action: {
                    self.isEditing = false
                    self.text = ""
                }) {
                    Text("Cancel")
                }
                .padding(.trailing, 10)
                .transition(.move(edge: .trailing))
            }
        }
        .padding()
    }
}

#Preview {
    ChooseExerciseView(
        title: "Choose sport",
        sport_list: [
            ChooseListModel(name: "Gym Exercises", image: "dumbbell", backColor:"blue_2"),
            ChooseListModel(name: "Ball Games", image: "sportscourt", backColor: "blue_0"),
            ChooseListModel(name: "Yoga", image: "figure.mind.and.body", backColor: "blue_3"),
            ChooseListModel(name: "Athletics", image: "figure.run", backColor: "blue_4"),
            ChooseListModel(name: "Swimming", image: "figure.pool.swim", backColor: "blue_5"),
            ChooseListModel(name: "Others", image: "ellipsis.circle", backColor: "blue_6")
        ]
    )
}
