//
//  AssessmentView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-04.
//

import SwiftUI
import Foundation

struct AssessmentView: View {
    @Binding var selectedTab: Int
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Text("AI Assessment")
                        .foregroundColor(Color("buttonColor"))
                        .font(.system(size:50, weight:.bold, design:.rounded))
                    Spacer()
                }
                .padding()
                Spacer()
                NavigationLink {
                    HumanBodyView()
                } label: {
                    Text("Assess your injuries HERE")
                        .frame(width: 360, height: 290)
                        .font(.system(size:40, weight:.bold, design:.rounded))
                        .foregroundColor(.white)
                        .background(Color("buttonColor"))
                        .cornerRadius(10)
                }
                Spacer()
                NavigationLink {
                    ChooseExerciseView(
                        title: "Choose sport",
                        sport_list: [
                            ChooseListModel(name: "Gym Exercises", image: "dumbbell", backColor:"blue_2"),
                            ChooseListModel(name: "Ball Games", image: "sportscourt", backColor: "blue_0"),
                            ChooseListModel(name: "Yoga", image: "figure.mind.and.body", backColor: "blue_3"),
                            ChooseListModel(name: "Athletics", image: "figure.run", backColor: "blue_4"),
                            ChooseListModel(name: "Swimming", image: "figure.pool.swim", backColor: "blue_5"),
                            ChooseListModel(name: "Others", image: "ellipsis.circle", backColor: "blue_6")
                        ]
                    )
                } label: {
                    Text("Assess your workout moves HERE")
                        .frame(width: 360, height: 290)
                        .font(.system(size:40, weight:.bold, design:.rounded))
                        .foregroundColor(.white)
                        .background(Color("buttonColor"))
                        .cornerRadius(10)
                }
                .padding(.vertical)
                
            }
        }
    }
}

#Preview {
    AssessmentView(selectedTab: .constant(1))
}
