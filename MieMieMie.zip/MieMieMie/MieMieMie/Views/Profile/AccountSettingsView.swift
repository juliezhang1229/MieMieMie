//
//  AccountSettingsView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-08.
//

import SwiftUI

struct AccountSettingsView: View {
    var body: some View {
        VStack {
            HStack {
                Text("Account Settings")
                    .font(.title2)
                    .bold()
                Spacer()
            }
            .padding(.vertical)
            HStack {
                ZStack {
                    RoundedRectangle(cornerRadius:5)
                        .foregroundStyle(Color("SquatBg"))
                        .frame(width:160, height:30)
                    RoundedRectangle(cornerRadius:5)
                        .stroke(Color("buttonColor"), lineWidth: 2)
                        .frame(width:160, height:30)
                    HStack {
                        Image(systemName:"gobackward")
                        Text("Reset Progress")
                    }
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius:5)
                        .foregroundStyle(Color("StepBg"))
                        .frame(width:140, height:30)
                    RoundedRectangle(cornerRadius:5)
                        .stroke(Color("StepIcon"), lineWidth: 2)
                        .frame(width:140, height:30)
                    HStack {
                        Image(systemName:"figure.wave")
                        Text("Accessibility")
                    }
                }
            }
            HStack {
                ZStack {
                    RoundedRectangle(cornerRadius: 15)
                        .frame(width:300,height:40)
                        .foregroundColor(Color(.systemGray6))
                    RoundedRectangle(cornerRadius:15)
                        .stroke(Color(.systemGray5), lineWidth:2)
                        .frame(width:300,height:40)
                    HStack {
                        Image(systemName:"doc.fill")
                        Text("Download Health Report")
                            .bold()
                    }
                }
                Spacer()
            }
            .padding(.vertical)
        }
        .padding()
        .frame(width: 370, height: 200)
        .background(Color(.white))
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 5)
    }
}

#Preview {
    AccountSettingsView()
}
