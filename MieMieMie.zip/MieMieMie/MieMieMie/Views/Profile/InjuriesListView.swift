//
//  InjuriesListView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-08.
//

import SwiftUI

struct InjuryListView: View {
    var injury: InjuryHistoryModel
    var body: some View {
        HStack {
            Text(injury.name)
            Spacer()
        }
        .padding(.vertical, 8)
        .padding(.horizontal)
    }
}

struct InjuriesListView: View {
    var Injury = [
        InjuryHistoryModel(name: "Triceps strain"),
        InjuryHistoryModel(name: "Ankle sprain"),
        InjuryHistoryModel(name: "Shoulder impingement")
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Injury History") // clearer section title
                    .font(.title2)
                    .bold()
                Spacer()
                NavigationLink {
                    UpperUpperTabView(title: "History")
                    ProgressView_()
                } label: {
                    Text("More")
                        .foregroundColor(.gray)
                }
            }
            .padding(.all)
            
            ForEach(Injury) { item in
                InjuryListView(injury: item)
                Divider()
                    .padding(.horizontal)
            }
        }
        .frame(width: 370, height: 200)
        .background(Color(.white))
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.3), radius: 8, x: 0, y: 5)
    }
}

#Preview {
    InjuriesListView()
}
