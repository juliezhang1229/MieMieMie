//
//  PersonalInfoView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-08.
//

import SwiftUI

struct PersonalInfoView: View {
    let PersonalInfo: PersonalInfoModel
    var body: some View {
        VStack(spacing:0) {
            HStack {
                Text("Personal Information")
                    .font(.title2)
                    .bold()
                Spacer()
                Button("Edit") {
                    //action
                }
                .font(.subheadline)
                .foregroundColor(.blue)
            }
            .padding(.all)
            HStack {
                Text("Name")
                    .foregroundColor(.secondary)
                    .frame(width:80, alignment:.leading)
                Spacer()
                Text(PersonalInfo.name)
                    .frame(alignment:.trailing)

            }
            .padding(.vertical,12)
            .padding(.horizontal)
            Divider()
            HStack {
                Text("Email")
                    .foregroundColor(.secondary)
                    .frame(width:80, alignment:.leading)
                Spacer()
                Text(PersonalInfo.email)
                    .frame(alignment:.trailing)

            }
            .padding(.vertical,12)
            .padding(.horizontal)
            Divider()
            HStack {
                Text("Joined")
                    .foregroundColor(.secondary)
                    .frame(width:80, alignment:.leading)
                Spacer()
                Text(PersonalInfo.joined)
                    .frame(alignment:.trailing)

            }
            .padding(.vertical,12)
            .padding(.horizontal)
            Divider()
            HStack {
                Text("Status")
                    .foregroundColor(.secondary)
                    .frame(width:80, alignment:.leading)
                Spacer()
                Text(PersonalInfo.status)
                    .frame(alignment:.trailing)

            }
            .padding(.vertical,12)
            .padding(.horizontal)
            Divider()
        }
        .frame(width: 370, height:250)
        .background(Color(.white))
        .cornerRadius(20)
        .shadow(color:.black.opacity(0.3), radius: 8, x:0, y:5)

    }
}

#Preview {
    PersonalInfoView(
        PersonalInfo: PersonalInfoModel(name: "Janja", email: "janja_garnbret@mie.com", joined: "Feb 2023", status: "Active Recovery", membership: "Premium Member")
    )
}
