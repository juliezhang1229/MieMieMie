import SwiftUI

struct CommunityPost: Identifiable {
    let id = UUID()
    let username: String
    let userId: String
    let content: String
    let hasImage: Bool
    let tags: [String]
    let likeCount: Int
    let commentCount: Int
}

struct CommunitiesView: View {
    @Binding var selectedTab: Int
    @State private var selectedCommunityTab = 0
    @State private var isSearching = false
    @State private var searchText = ""
    
    private let samplePosts: [CommunityPost] = [
        .init(
            username: "User name",
            userId: "User id 123456789",
            content: "Day 90 recovery journey-What did I do when encountering ACL #ACL #Recovery journey",
            hasImage: true,
            tags: ["#Recovery", "#ACL", "#Day90"],
            likeCount: 128,
            commentCount: 24
        ),
        .init(
            username: "User name",
            userId: "User id 987654321",
            content: "#Recovery Day 50 # Recovery Check in",
            hasImage: false,
            tags: ["#Recovery", "#CheckIn"],
            likeCount: 64,
            commentCount: 12
        ),
        .init(
            username: "User name",
            userId: "User id 123456789",
            content: "#Recovery Day 50 # Recovery Check in",
            hasImage: true,
            tags: ["#Recovery"],
            likeCount: 42,
            commentCount: 8
        )
    ]
    
    var body: some View {
        ZStack(alignment: .top) {
            NavigationView {
                VStack(spacing: 0) {
                    Text("Community")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(Color(red: 0.42, green: 0.63, blue: 0.95))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.horizontal, 16)
                        .padding(.top, 8)
                    
                    HStack(spacing: 2) {
                        TabButton(title: "Recommend", isSelected: selectedCommunityTab == 0) {
                            selectedCommunityTab = 0
                        }
                        TabButton(title: "Recovery", isSelected: selectedCommunityTab == 1) {
                            selectedCommunityTab = 1
                        }
                        TabButton(title: "Exercise", isSelected: selectedCommunityTab == 2) {
                            selectedCommunityTab = 2
                        }
                        Spacer()
                        Button {
                            withAnimation(.spring(response: 0.32, dampingFraction: 0.85)) {
                                isSearching = true
                            }
                        } label: {
                            Image(systemName: "magnifyingglass")
                                .foregroundColor(Color(red: 0.42, green: 0.63, blue: 0.95))
                                .font(.system(size: 20))
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    
                    Divider()
                    
                    ScrollView {
                        LazyVStack(spacing: 0) {
                            ForEach(samplePosts) { post in
                                NavigationLink {
                                    CommunityPostDetailView(post: post)
                                } label: {
                                    CommunityPostView(
                                        username: post.username,
                                        userId: post.userId,
                                        content: post.content,
                                        hasImage: post.hasImage,
                                        tags: post.tags,
                                        likeCount: post.likeCount,
                                        commentCount: post.commentCount
                                    )
                                }
                                .buttonStyle(.plain)
                                
                                if post.id != samplePosts.last?.id {
                                    Divider()
                                        .padding(.horizontal, 16)
                                }
                            }
                        }
                    }
                    
                    Spacer()
                }
                .navigationBarHidden(true)
            }
            
            if isSearching {
                searchOverlay
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    private var searchOverlay: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(Color.gray.opacity(0.6))
                    TextField("搜索话题、用户或标签", text: $searchText)
                        .textFieldStyle(.plain)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                
                Button("取消") {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                        searchText = ""
                        isSearching = false
                    }
                }
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            
            VStack(alignment: .leading, spacing: 16) {
                Text("常用搜索")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(Color.gray)
                
                ForEach(["恢复计划", "ACL 康复", "每日打卡"], id: \.self) { suggestion in
                    Button {
                        searchText = suggestion
                    } label: {
                        Text(suggestion)
                            .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
            .padding(16)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            .padding(.horizontal, 16)
            
            Spacer()
        }
        .background(
            Color.black.opacity(0.22)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isSearching = false
                    }
                }
        )
    }
}

struct TabButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Text(title)
                    .font(.system(size: 16, weight: isSelected ? .semibold : .regular))
                    .foregroundColor(Color(red: 0.42, green: 0.63, blue: 0.95))
                
                if isSelected {
                    Rectangle()
                        .fill(Color(red: 0.42, green: 0.63, blue: 0.95))
                        .frame(height: 2)
                } else {
                    Rectangle()
                        .fill(Color.clear)
                        .frame(height: 2)
                }
            }
        }
    }
}

struct CommunityPostView: View {
    let username: String
    let userId: String
    let content: String
    let hasImage: Bool
    let tags: [String]
    let likeCount: Int
    let commentCount: Int
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top, spacing: 12) {
                Circle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 48, height: 48)
                
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text(username)
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                        Spacer()
                        Button(action: {}) {
                            Image(systemName: "ellipsis")
                                .rotationEffect(.degrees(90))
                                .foregroundColor(Color.gray)
                        }
                    }
                    
                    Text(userId)
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                    
                    Text(content)
                        .font(.system(size: 14))
                        .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                        .lineLimit(3)
                        .multilineTextAlignment(.leading)
                }
            }
            
            if hasImage {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.gray.opacity(0.1))
                    .frame(height: 180)
            }
            
            if !tags.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(tags, id: \.self) { tag in
                            Text(tag)
                                .font(.system(size: 12, weight: .medium))
                                .padding(.vertical, 6)
                                .padding(.horizontal, 12)
                                .background(Color(red: 0.91, green: 0.96, blue: 1.0))
                                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                                .clipShape(Capsule())
                        }
                    }
                }
            }
            
            Divider()
            
            HStack {
                HStack(spacing: 4) {
                    Image(systemName: "hand.thumbsup.fill")
                    Text("\(likeCount)")
                }
                .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                
                HStack(spacing: 4) {
                    Image(systemName: "bubble.left.and.bubble.right.fill")
                    Text("\(commentCount)")
                }
                .foregroundColor(Color.gray)
                
                Spacer()
                
                Button(action: {}) {
                    Text("Follow")
                        .font(.system(size: 14, weight: .semibold))
                        .padding(.vertical, 6)
                        .padding(.horizontal, 16)
                        .background(Color(red: 0.32, green: 0.52, blue: 0.91))
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                }
            }
            .font(.system(size: 13))
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 6)
        )
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
    }
}

struct CommunityPostDetailView: View {
    let post: CommunityPost
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if post.hasImage {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.gray.opacity(0.1))
                        .frame(height: 220)
                        .overlay(
                            Text("封面图占位")
                                .foregroundColor(.gray)
                        )
                        .padding(.horizontal, 16)
                }
                
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .top, spacing: 12) {
                        Circle()
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 52, height: 52)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(post.username)
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                            
                            Text(post.userId)
                                .font(.system(size: 13))
                                .foregroundColor(.gray)
                        }
                        Spacer()
                        Button {
                            // follow action
                        } label: {
                            Text("Follow")
                                .font(.system(size: 15, weight: .semibold))
                                .padding(.vertical, 6)
                                .padding(.horizontal, 20)
                                .background(Color(red: 0.32, green: 0.52, blue: 0.91))
                                .foregroundColor(.white)
                                .clipShape(Capsule())
                        }
                    }
                    
                    Text(post.content)
                        .font(.system(size: 15))
                        .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                        .lineSpacing(6)
                }
                .padding(.horizontal, 16)
                
                if !post.tags.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(post.tags, id: \.self) { tag in
                                Text(tag)
                                    .font(.system(size: 12, weight: .medium))
                                    .padding(.vertical, 6)
                                    .padding(.horizontal, 14)
                                    .background(Color(red: 0.91, green: 0.96, blue: 1.0))
                                    .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                                    .clipShape(Capsule())
                            }
                        }
                        .padding(.horizontal, 16)
                    }
                }
                
                VStack(alignment: .leading, spacing: 16) {
                    Text("Comments")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                    
                    ForEach(0..<3) { _ in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack(spacing: 10) {
                                Circle()
                                    .fill(Color.gray.opacity(0.2))
                                    .frame(width: 36, height: 36)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Comment user")
                                        .font(.system(size: 14, weight: .semibold))
                                    Text("1h ago")
                                        .font(.system(size: 12))
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                                Button {
                                    // like comment
                                } label: {
                                    Image(systemName: "hand.thumbsup")
                                }
                            }
                            
                            Text("这里是示例评论内容，后续替换为真实数据。")
                                .font(.system(size: 14))
                                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                                .lineSpacing(4)
                        }
                        .padding()
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: 4)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
            .padding(.top, 16)
        }
        .background(Color(UIColor.systemGroupedBackground))
        .navigationTitle("Post Detail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    // share or more actions
                } label: {
                    Image(systemName: "square.and.arrow.up")
                }
            }
        }
    }
}

#Preview {
    CommunitiesView(selectedTab: .constant(3))
}

