//
//  SettingsView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-05.
//

import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    
    // 账号与安全
    @State private var twoFactorEnabled = true
    @State private var loginAlertsEnabled = false
    
    // 通知
    @State private var muteAll = false
    @State private var daytimeOnly = true
    @State private var trainingReminders = true
    @State private var recoveryReminders = true
    @State private var socialNotifications = true
    @State private var emailDigest = false
    
    // 设备与数据
    @State private var syncAppleHealth = true
    @State private var syncGoogleFit = false
    @State private var autoImportWearable = true
    @State private var shareWithCoach = true
    
    // 隐私与社交
    @State private var allowDM = true
    @State private var showOnDiscover = false
    @State private var autoShareSessions = false
    @State private var allowComments = true
    @State private var reviewBeforePublish = true
    
    // 应用偏好
    @State private var darkModeFollowSystem = true
    @State private var useMetric = true
    @State private var enableVoiceAssist = false
    @State private var hapticFeedback = true
    @State private var autoplayVideo = true
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    headerCard
                    
                    // 账号与安全
                    settingSection(title: "账号与安全") {
                        settingsRow(icon: "person.crop.circle", title: "个人资料", detail: "头像、昵称、职业身份") { }
                        settingsRow(icon: "lock.rotation", title: "修改密码", detail: "重设登录密码") { }
                        toggleRow(icon: "shield.checkerboard", title: "两步验证", caption: "通过短信或验证器提高账号安全性", isOn: $twoFactorEnabled)
                        toggleRow(icon: "desktopcomputer.and.arrow.down", title: "异常登录提醒", caption: "检测到新设备登录时通知我", isOn: $loginAlertsEnabled)
                        settingsRow(icon: "link.circle", title: "账号绑定", detail: "手机号、邮箱、第三方登录") { }
                        settingsRow(icon: "key.horizontal", title: "设备与登录记录", detail: "管理已登录设备") { }
                    }
                    
                    // 付费与会员
                    settingSection(title: "会员与支付") {
                        settingsRow(icon: "crown.fill", title: "会员中心", detail: "查看权益与等级成长") { }
                        settingsRow(icon: "creditcard.and.123", title: "支付方式", detail: "银行卡、Apple Pay、微信等") { }
                        settingsRow(icon: "calendar.badge.exclamationmark", title: "自动续费设置", detail: "管理订阅与到期提醒") { }
                        settingsRow(icon: "giftcard", title: "优惠券与积分", detail: "兑换码、积分明细") { }
                        settingsRow(icon: "doc.plaintext", title: "发票与报销", detail: "下载电子发票") { }
                    }
                    
                    // 通知与提醒
                    settingSection(title: "通知与提醒") {
                        toggleRow(icon: "bell.slash.fill", title: "静音所有通知", caption: "必要系统提醒除外", isOn: $muteAll)
                        toggleRow(icon: "clock.arrow.circlepath", title: "仅在 08:00-22:00 推送", caption: "夜间自动静音", isOn: $daytimeOnly)
                        toggleRow(icon: "figure.run", title: "训练提醒", caption: "按计划提醒你完成训练", isOn: $trainingReminders)
                        toggleRow(icon: "bandage.fill", title: "康复与健康提醒", caption: "康复训练、放松、复诊提醒", isOn: $recoveryReminders)
                        toggleRow(icon: "bubble.left.and.bubble.right.fill", title: "社交互动提醒", caption: "评论、点赞、关注、私信", isOn: $socialNotifications)
                        toggleRow(icon: "envelope.fill", title: "邮件周报", caption: "每周发送训练与健康总结", isOn: $emailDigest)
                    }
                    
                    // 设备与数据
                    settingSection(title: "设备与数据") {
                        toggleRow(icon: "applewatch", title: "同步 Apple Health", caption: "步数、心率、睡眠等数据", isOn: $syncAppleHealth)
                        toggleRow(icon: "figure.wave.circle", title: "同步 Google Fit", caption: "连接 Android 健康数据", isOn: $syncGoogleFit)
                        toggleRow(icon: "antenna.radiowaves.left.and.right", title: "自动导入穿戴设备数据", caption: "已连接的手环、手表", isOn: $autoImportWearable)
                        toggleRow(icon: "person.2.wave.2.fill", title: "与教练共享训练记录", caption: "便于教练远程指导", isOn: $shareWithCoach)
                        settingsRow(icon: "personalhotspot", title: "连接新设备", detail: "添加更多手环、训练器械") { }
                        settingsRow(icon: "tray.full", title: "数据导出与备份", detail: "导出训练日志与体测数据") { }
                    }
                    
                    // 隐私与社交
                    settingSection(title: "隐私与社交") {
                        toggleRow(icon: "message.fill", title: "允许陌生人私信", caption: "关闭后仅好友可私信", isOn: $allowDM)
                        toggleRow(icon: "sparkles", title: "在发现页展示动态", caption: "让更多人看到你的训练记录", isOn: $showOnDiscover)
                        toggleRow(icon: "square.and.arrow.up", title: "自动分享训练完成卡片", caption: "每次完成训练自动分享到社区", isOn: $autoShareSessions)
                        toggleRow(icon: "bubble.left", title: "允许他人评论我的帖子", caption: "控制社交互动范围", isOn: $allowComments)
                        toggleRow(icon: "checkmark.shield.fill", title: "发布前需要我审核", caption: "系统提醒手动确认再公开", isOn: $reviewBeforePublish)
                        settingsRow(icon: "hand.raised.fill", title: "黑名单与举报记录", detail: "查看屏蔽用户与举报进度") { }
                        settingsRow(icon: "doc.text.magnifyingglass", title: "隐私政策", detail: "了解数据如何被使用") { }
                    }
                    
                    // 应用偏好
                    settingSection(title: "应用偏好") {
                        toggleRow(icon: "circle.lefthalf.filled", title: "跟随系统深色模式", caption: "关闭后可手动切换", isOn: $darkModeFollowSystem)
                        toggleRow(icon: "ruler", title: "使用公制单位", caption: "公里、千克等", isOn: $useMetric)
                        toggleRow(icon: "waveform", title: "语音播报训练步骤", caption: "训练时播报提示语", isOn: $enableVoiceAssist)
                        toggleRow(icon: "hand.tap.fill", title: "触觉反馈", caption: "关键操作时轻微震动提示", isOn: $hapticFeedback)
                        toggleRow(icon: "play.circle.fill", title: "自动播放训练视频", caption: "进入详情页自动开始播放", isOn: $autoplayVideo)
                        settingsRow(icon: "textformat.size", title: "字体与字号", detail: "正文字号、标题大小") { }
                        settingsRow(icon: "globe", title: "语言设置", detail: "中文、英文等") { }
                        settingsRow(icon: "trash.fill", title: "缓存与存储空间", detail: "清理离线视频与缓存") { }
                    }
                    
                    // 帮助与支持
                    settingSection(title: "帮助与关于") {
                        settingsRow(icon: "questionmark.circle", title: "帮助中心", detail: "常见问题、使用指南") { }
                        settingsRow(icon: "square.and.pencil", title: "意见反馈", detail: "提交建议或问题") { }
                        settingsRow(icon: "phone.bubble.left", title: "联系客服", detail: "在线客服、电话、邮件") { }
                        settingsRow(icon: "book", title: "社区规范", detail: "发布守则与内容标准") { }
                        settingsRow(icon: "info.circle", title: "关于我们", detail: "版本号、更新日志") { }
                        settingsRow(icon: "doc.text", title: "服务条款", detail: "用户协议与使用条款") { }
                        settingsRow(icon: "cross.case.fill", title: "医疗免责声明", detail: "专业医疗建议说明") { }
                        settingsRow(icon: "rectangle.portrait.and.arrow.right", title: "注销账号", detail: "删除全部个人数据") { }
                    }
                    
                    // 按钮
                    Button {
                        // TODO: 退出登录
                    } label: {
                        Text("退出登录")
                            .font(.system(size: 16, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .foregroundColor(.white)
                            .background(Color(red: 0.85, green: 0.13, blue: 0.21))
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.top, 24)
                .padding(.bottom, 40)
            }
            .background(Color(UIColor.systemGroupedBackground))
            //.navigationTitle("设置")
            .navigationBarTitleDisplayMode(.inline)
            /*.toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("完成") { dismiss() }
                }
            }*/
        }
    }
    
    // MARK: - 子视图
    
    private var headerCard: some View {
        HStack(spacing: 16) {
            Circle()
                .fill(Color.gray.opacity(0.2))
                .frame(width: 72, height: 72)
                .overlay(
                    Text("头像")
                        .foregroundColor(.gray)
                        .font(.system(size: 13))
                )
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Therapist Anne")
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                
                Text("ID 3049583")
                    .font(.system(size: 13))
                    .foregroundColor(.gray)
                
                HStack(spacing: 12) {
                    statCapsule(value: "128", label: "关注")
                    statCapsule(value: "6.5k", label: "粉丝")
                    statCapsule(value: "932", label: "帖子")
                }
            }
            
            Spacer()
            
            Button {
                // TODO: 编辑资料
            } label: {
                Image(systemName: "pencil")
                    .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                    .padding(10)
                    .background(Color(red: 0.91, green: 0.96, blue: 1.0))
                    .clipShape(Circle())
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.1), radius: 14, x: 0, y: 8)
        )
        .padding(.horizontal, 20)
    }
    
    private func statCapsule(value: String, label: String) -> some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
            Text(label)
                .font(.system(size: 11))
                .foregroundColor(.gray)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color.gray.opacity(0.08))
        .clipShape(Capsule())
    }
    
    private func settingSection(title: String, @ViewBuilder content: () -> some View) -> some View {
        VStack(spacing: 12) {
            HStack {
                Text(title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                Spacer()
            }
            .padding(.horizontal, 20)
            
            VStack(spacing: 0) {
                content()
            }
            .background(
                RoundedRectangle(cornerRadius: 20, style: .continuous)
                    .fill(Color.white)
                    .shadow(color: Color.black.opacity(0.05), radius: 12, x: 0, y: 6)
            )
            .padding(.horizontal, 20)
        }
    }
    
    private func settingsRow(icon: String, title: String, detail: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 20))
                    .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                    .frame(width: 32, height: 32)
                    .background(Color(red: 0.91, green: 0.96, blue: 1.0))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(title)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                    Text(detail)
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(Color.gray.opacity(0.5))
            }
            .padding(.vertical, 14)
            .padding(.horizontal, 20)
        }
        .buttonStyle(.plain)
        .overlay(
            Divider()
                .padding(.leading, 66),
            alignment: .bottom
        )
    }
    
    private func toggleRow(icon: String, title: String, caption: String, isOn: Binding<Bool>) -> some View {
        Toggle(isOn: isOn) {
            VStack(alignment: .leading, spacing: 6) {
                Text(title)
                    .font(.system(size: 15, weight: .medium))
                    .foregroundColor(Color(red: 0.16, green: 0.24, blue: 0.45))
                Text(caption)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
        }
        .toggleStyle(SwitchToggleStyle(tint: Color(red: 0.32, green: 0.52, blue: 0.91)))
        .padding(.vertical, 12)
        .padding(.horizontal, 20)
        .background(
            HStack {
                Image(systemName: icon)
                    .font(.system(size: 18))
                    .foregroundColor(Color(red: 0.32, green: 0.52, blue: 0.91))
                    .frame(width: 32, height: 32)
                    .background(Color(red: 0.91, green: 0.96, blue: 1.0))
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                Spacer()
            }
            .padding(.leading, 20)
        )
    }
}


#Preview {
    SettingsView()
}
