//
//  HomeView.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-03.
//

import SwiftUI

struct HomeView: View {
    @Binding var selectedTab: Int
    @State private var showRecovery = false
    
    let communities = [
        CommunityCard(title:"Tennis elbow rehabilitation training", imageName: "tennisElbow"),
        CommunityCard(title: "The right way to apply muscle tape to your tendon", imageName: "muscleTape")
    ]
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Text("Hello")
                        .foregroundColor(Color("buttonColor"))
                        .font(.system(size:70,weight:.bold, design:.rounded))
                        .padding()
                    Spacer()
                    NavigationLink {
                        UpperUpperTabView(title: "Settings")
                        SettingsView()
                    } label: {
                        Image(systemName:"ellipsis.circle")
                            .font(.system(size:40))
                            .bold()
                            .foregroundColor(Color("buttonColor"))
                            .padding()
                    }
                }
                
                VStack(spacing:15) {
                    HStack(spacing:15) {
                        NavigationLink {
                            ChooseExerciseView(
                                title: "Choose sport",
                                sport_list: [
                                    ChooseListModel(name: "Gym Exercises", image: "dumbbell", backColor:"blue_2"),
                                    ChooseListModel(name: "Ball Games", image: "sportscourt", backColor: "blue_0"),
                                    ChooseListModel(name: "Yoga", image: "figure.mind.and.body", backColor: "blue_3"),
                                    ChooseListModel(name: "Athletics", image: "figure.run", backColor: "blue_4"),
                                    ChooseListModel(name: "Swimming", image: "figure.pool.swim", backColor: "blue_5"),
                                    ChooseListModel(name: "Others", image: "ellipsis.circle", backColor: "blue_6")
                                ]
                            )
                        } label: {
                            Text("Assess your\nMOVES")
                            .frame(width: 175, height: 150)
                            .font(.title)
                            .bold()
                            .foregroundColor(.white)
                            .background(Color("buttonColor"))
                            .cornerRadius(10)
                        }
                        NavigationLink {
                            HumanBodyView()
                        } label: {
                            Text("Assess your INJURIES")
                                .frame(width: 175, height: 150)
                                .font(.title)
                                .bold()
                                .foregroundColor(.white)
                                .background(Color("buttonColor"))
                                .cornerRadius(10)
                        }
                    }
                    HStack {
                        Button ("RECOVERY\nPlan") {
                            showRecovery = true
                        }
                        .frame(width: 250, height: 150)
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .background(Color("buttonColor"))
                        .cornerRadius(10)
                        .navigationDestination(isPresented: $showRecovery) {
                            RecoveryView(selectedTab: .constant(2))
                                .navigationBarBackButtonHidden(true)
                        }
                    }
                }
                VStack {
                    HStack {
                        Text("Community")
                            .font(.system(size:50, weight:.bold, design:.rounded))
                            .foregroundColor(Color("buttonColor"))
                            .padding()
                        Spacer()
                    }
                    
                    ScrollView(.horizontal) {
                        LazyHStack(spacing:10) {
                            ForEach(communities) {
                                community in
                                CommunityCardView(community: community)
                            }
                        }
                    }
                    .padding()
                    .offset(y:-20)
                }
            }
            //Spacer()
        }
    }
}

struct CommunityCardView: View {
    let community: CommunityCard
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(community.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 200, height: 120)
                .cornerRadius(8)
            Text(community.title)
                .font(.system(size:15))
                .bold()
                .foregroundColor(Color("buttonColor"))
                .multilineTextAlignment(.leading)
                //.fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
        .frame(width: 200, height:150)
    }
}


#Preview {
    HomeView(selectedTab: .constant(0))
}
