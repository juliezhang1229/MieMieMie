//
//  DecodeJson.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-04.
//

import Foundation

/*func decode(_ file: String) -> [ExerciseTabModel] {
    guard let url = Bundle.main.url(forResource: file, withExtension: nil) else {
        fatalError("Failed to locate \(file) in bundle")
    }
    guard let data = try? Data(contentsOf: url) else {
        fatalError("Failed to load file from \(file) from bundle")
    }
    let decoder = JSONDecoder()
    guard let loadedFile = try? decoder.decode([ExerciseTabModel].self, from: data) else {
        fatalError("Failed to decode \(file) from bundle")
    }
    return loadedFile
}*/
