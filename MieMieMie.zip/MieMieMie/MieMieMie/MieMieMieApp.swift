//
//  MieMieMieApp.swift
//  MieMieMie
//
//  Created by Julie Zhang on 2025-11-03.
//

import SwiftUI

@main
struct MieMieMieApp: App {
    var body: some Scene {
        WindowGroup {
            MainAppView()
        }
    }
}
